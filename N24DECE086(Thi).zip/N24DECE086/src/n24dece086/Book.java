package n24dece086;

public abstract class Book {
    private String maSach;
    private String tenSach;
    private double giaNhap;
    private int soLuong;
  // Constructor
    public Book(String maSach, String tenSach,
                double giaNhap, int soLuong) {
        this.maSach = maSach;
        this.tenSach = tenSach;
        this.giaNhap = giaNhap;
        this.soLuong = soLuong;
    }

    // Getters
    public String getMaSach() {
        return maSach;
    }
    public String getTenSach() {
        return tenSach;
    }
    public double getGiaNhap() {
        return giaNhap;
    }
    public int getSoLuong() {
        return soLuong;
    }

    // Setters
    public void setMaSach(String maSach) {
        this.maSach = maSach;
    }

    public void setTenSach(String tenSach) {
        this.tenSach = tenSach;
    }

    public void setGiaNhap(double giaNhap) throws InvalidBookException {
        if (giaNhap < 0) {
            throw new InvalidBookException("Gia nhap khong duoc am!");
        }

        this.giaNhap = giaNhap;
    }
    public void setSoLuong(int soLuong) throws InvalidBookException {
        if (soLuong < 0) {
            throw new InvalidBookException("So luong khong duoc am!");
        }

        this.soLuong = soLuong;
    }
    // Phuong thuc truu tuong
    public abstract double tinhGiaBan();

    public abstract String moTa();
    // Phuong thuc thong thuong 
    public String thongTin() {
        return "Ma sach: " + maSach
                + "\nTen sach: " + tenSach
                + "\nGia nhap: " + giaNhap
                + "\nSo luong: " + soLuong
                + "\nGia ban: " + tinhGiaBan()
                + "\nMo ta: " + moTa();
    }
}