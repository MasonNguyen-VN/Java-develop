package n24dece086;

public interface Promotable {

    double apDungKhuyenMai(double phanTram);

    double getGiaGoc();

    double getMucKhuyenMai();

    default void inGiaKhuyenMai() {
        double giaGoc = getGiaGoc();
        double phanTram = getMucKhuyenMai();
        double giaKhuyenMai = apDungKhuyenMai(phanTram);

        System.out.printf(
                "Gia goc: %.0f -> Gia KM (%.0f%%): %.0f%n",
                giaGoc, phanTram, giaKhuyenMai
        );
    }
}