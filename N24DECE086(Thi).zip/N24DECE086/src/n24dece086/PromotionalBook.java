package n24dece086;

public class PromotionalBook extends Novel implements Promotable {
    private double mucKhuyenMai;

    public PromotionalBook(String maSach, String tenSach,
                           double giaNhap, int soLuong,
                           String tacGia, int namXuatBan,
                           double mucKhuyenMai) {
        super(maSach, tenSach, giaNhap, soLuong,
              tacGia, namXuatBan);
        this.mucKhuyenMai = mucKhuyenMai;
    }

    @Override
    public double getGiaGoc() {
        return tinhGiaBan();
    }

    @Override
    public double getMucKhuyenMai() {
        return mucKhuyenMai;
    }

    public void setMucKhuyenMai(double mucKhuyenMai) {
        this.mucKhuyenMai = mucKhuyenMai;
    }

    @Override
    public double apDungKhuyenMai(double phanTram) {
        return tinhGiaBan() * (1 - phanTram / 100);
    }

    @Override
    public String moTa() {
        return super.moTa()
                + ", Khuyen mai: " + mucKhuyenMai + "%";
    }

    @Override
    public String toString() {
        return thongTin();
    }
}