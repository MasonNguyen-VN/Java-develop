package n24dece086;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        BookManager quanLy = new BookManager();

        // khoi tao
        Book s1 = new TextBook(
                "S001", "Lap trinh Java co ban",
                80000, 50, "Ga Lap Trinh Jave", 350
        );

        Book s2 = new Novel(
                "S002", "Street Wall",
                55000, 120, "Mr Mason", 1936
        );

        Book s3 = new Magazine(
                "S003", "Tap chi PC World",
                30000, 200, 12, "Hang thang"
        );

        Book s4 = new TextBook(
                "S004", "Giai tich ",
                65000, 30, "Math", 280
        );

        Book s5 = new Novel(
                "S005", "Create OS",
                120000, 0, "Bill Gate", 1997
        );

        try {
            quanLy.themSach(s1);
            quanLy.themSach(s2);
            quanLy.themSach(s3);
            quanLy.themSach(s4);
            quanLy.themSach(s5);
        } catch (InvalidBookException e) {
            System.out.println("Loi khi khoi tao sach: " + e.getMessage());
        } finally {
            System.out.println("=== Hoan tat khoi tao ===");
        }

        // In 
        System.out.println("===== DANH SACH SACH =====");
        quanLy.inDanhSach();

        // Tim
        System.out.println("\n===== TIM SACH THEO MA =====");

        Book sachTimDuoc = quanLy.timTheoMa("S002");

        if (sachTimDuoc != null) {
            System.out.println(sachTimDuoc);
        } else {
            System.out.println("Khong tim thay sach!");
        }

        // Tim sach theo ten
        System.out.println("\n===== TIM SACH THEO TEN =====");
        ArrayList<Book> ketQua = quanLy.timTheoTen("Java");

        if (ketQua.isEmpty()) {
            System.out.println("Khong tim thay sach!");
        } else {
            for (Book b : ketQua) {
                System.out.println(b);
            }
        }

        // Thu them sach co ma trung
        System.out.println("\n===== KIEM TRA MA TRUNG =====");
        Book sachTrung = new Novel(
        	    "S002", "Sach thu nghiem", 40000, 10,
        	    "Tac gia thu nghiem", 2025
        	);

        	try {
        	    quanLy.themSach(sachTrung);
        	} catch (InvalidBookException e) {
        	    System.out.println("Loi: " + e.getMessage());
        	}

        // Xoa Sach ( chay thu s004)
        System.out.println("\n===== XOA SACH =====");
        quanLy.xoaSach("S004");
        quanLy.inDanhSach();

        // Tinh khuyen mai
        System.out.println("\n===== SACH CO KHUYEN MAI =====");

        PromotionalBook sachKM = new PromotionalBook(
            "S006", "Lap trinh Java nang cao",
            100000, 20, "Nguyen Van A", 2025, 20
        );

        try {
            quanLy.themSach(sachKM);
        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        System.out.println(sachKM);
        sachKM.inGiaKhuyenMai();
        // check null
        System.out.println("\n===== KIEM TRA SACH NULL =====");

        try {
            quanLy.themSach(null);
        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        
        System.out.println("\n===== KIEM TRA GIA NHAP AM =====");

        try {
            s1.setGiaNhap(-50000);
            System.out.println("Cap nhat gia nhap thanh cong!");
        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        System.out.println("\n===== DA HINH: THONG TIN CAC SACH =====");

        for (Book b : quanLy.getDanhSach()) {
            System.out.println("Ma sach: " + b.getMaSach());
            System.out.println("Ten sach: " + b.getTenSach());
            System.out.println("Gia ban: " + b.tinhGiaBan());
            System.out.println("Mo ta: " + b.moTa());
            System.out.println("-----------------------------");
        }
        System.out.println("\n===== THONG KE KHUYEN MAI VA DOANH THU =====");

        int soSachKhuyenMai = 0;
        double tongDoanhThu = 0;

        for (Book b : quanLy.getDanhSach()) {
            tongDoanhThu += b.tinhGiaBan() * b.getSoLuong();

            if (b instanceof Promotable) {
                soSachKhuyenMai++;

                Promotable p = (Promotable) b;
                p.inGiaKhuyenMai();
            }
        }

        System.out.println("So sach co khuyen mai: " + soSachKhuyenMai);
        System.out.printf("Tong doanh thu du kien: %.0f VND%n", tongDoanhThu);
        System.out.println("\n===== KIEM TRA SO LUONG AM =====");

        try {
            s1.setSoLuong(-10);
        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }
        System.out.println("\n===== KIEM TRA MA SACH RONG =====");

        Book sachLoi = new Novel(
            "", "Sach thu nghiem", 50000, 10,
            "Tac gia thu nghiem", 2025
        );

        try {
            quanLy.themSach(sachLoi);
        } catch (InvalidBookException e) {
            System.out.println("Loi: " + e.getMessage());
        }

        System.out.println("\n===== SAP XEP SACH THEO GIA BAN TANG DAN =====");

        quanLy.sapXepTheoGiaBanTangDan();
        quanLy.inDanhSach();
        
        System.out.println("\n===== AP DUNG KHUYEN MAI 20% CHO TAT CA SACH =====");

        for (Book b : quanLy.getDanhSach()) {
            System.out.println("\nSach: " + b.getTenSach());

            double giaGoc = b.tinhGiaBan();
            double giaKhuyenMai;

            if (b instanceof PromotionalBook) {
                PromotionalBook pb = (PromotionalBook) b;

                pb.setMucKhuyenMai(20);
                pb.inGiaKhuyenMai();

                giaKhuyenMai = pb.apDungKhuyenMai(20);
            } else {
                giaKhuyenMai = giaGoc * (1 - 20.0 / 100);

                System.out.printf(
                    "Gia goc: %.0f -> Gia KM (20%%): %.0f%n",
                    giaGoc, giaKhuyenMai
                );
            }
        }
        System.out.println("\n===== KET THUC CHUONG TRINH =====");
    }
}