package n24dece086;

public class Magazine extends Book {
    private int soKy;
    private String tanSuatXuatBan;

    public Magazine(String maSach, String tenSach,
                    double giaNhap, int soLuong,
                    int soKy, String tanSuatXuatBan) {
        super(maSach, tenSach, giaNhap, soLuong);
        this.soKy = soKy;
        this.tanSuatXuatBan = tanSuatXuatBan;
    }

    public int getSoKy() {
        return soKy;
    }

    public void setSoKy(int soKy) {
        this.soKy = soKy;
    }

    public String getTanSuatXuatBan() {
        return tanSuatXuatBan;
    }

    public void setTanSuatXuatBan(String tanSuatXuatBan) {
        this.tanSuatXuatBan = tanSuatXuatBan;
    }

    @Override
    public double tinhGiaBan() {
        return getGiaNhap() * 1.10;
    }

    @Override
    public String moTa() {
        return "So ky: " + soKy
                + ", Tan suat xuat ban: " + tanSuatXuatBan;
    }

    @Override
    public String toString() {
        return thongTin();
    }	
}