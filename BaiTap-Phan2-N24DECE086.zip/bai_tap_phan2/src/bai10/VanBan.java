package bai10;

public class VanBan {
    private String st;

    // Constructor không tham số
    public VanBan() {
        st = "";
    }

    // Constructor có tham số
    public VanBan(String st) {
        this.st = st;
    }

    // Đếm số từ
    public int demSoTu() {
        String s = st.trim();

        if (s.isEmpty()) {
            return 0;
        }

        String[] words = s.split("\\s+");
        return words.length;
    }

    // Đếm số lần xuất hiện ký tự A hoặc a
    public int demKyTuA() {
        int dem = 0;

        for (int i = 0; i < st.length(); i++) {
            char c = Character.toLowerCase(st.charAt(i));

            if (c == 'a') {
                dem++;
            }
        }

        return dem;
    }

    // Chuẩn hóa văn bản
    public void chuanHoa() {
        st = st.trim().replaceAll("\\s+", " ");
    }

    // Hiển thị văn bản
    public void hienThi() {
        System.out.println(st);
    }
}