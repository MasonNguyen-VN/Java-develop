package bai10;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Nhap van ban: ");
        String s = sc.nextLine();

        VanBan vb = new VanBan(s);

        System.out.println("So tu: " + vb.demSoTu());
        System.out.println("So ky tu A/a: " + vb.demKyTuA());

        vb.chuanHoa();

        System.out.print("Van ban sau khi chuan hoa: ");
        vb.hienThi();

        sc.close();
    }
}