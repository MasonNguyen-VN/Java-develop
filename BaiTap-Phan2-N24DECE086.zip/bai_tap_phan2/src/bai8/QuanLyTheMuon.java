package bai8;

import java.util.ArrayList;

public class QuanLyTheMuon {
    private ArrayList<TheMuon> danhSach = new ArrayList<>();

    // Them the muon
    public void themTheMuon(TheMuon the) {
        for (TheMuon item : danhSach) {
            if (item.getMaPhieuMuon()
                    .equalsIgnoreCase(the.getMaPhieuMuon())) {
                System.out.println("Ma phieu muon da ton tai!");
                return;
            }
        }

        danhSach.add(the);
        System.out.println("Them the muon thanh cong!");
    }

    // Xoa theo ma phieu muon
    public void xoaTheMuon(String maPhieuMuon) {
        for (int i = 0; i < danhSach.size(); i++) {
            if (danhSach.get(i).getMaPhieuMuon()
                    .equalsIgnoreCase(maPhieuMuon)) {

                danhSach.remove(i);
                System.out.println("Xoa the muon thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay ma phieu muon!");
    }

    // Hien thi danh sach
    public void hienThiDanhSach() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach the muon trong!");
            return;
        }

        for (TheMuon the : danhSach) {
            the.hienThi();
        }
    }
}