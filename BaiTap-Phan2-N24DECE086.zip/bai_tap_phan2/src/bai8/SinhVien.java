package bai8;

public class SinhVien {
    private String hoTen;
    private int tuoi;
    private String lop;

    public SinhVien(String hoTen, int tuoi, String lop) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.lop = lop;
    }

    public void hienThi() {
        System.out.println("Ho ten sinh vien: " + hoTen);
        System.out.println("Tuoi: " + tuoi);
        System.out.println("Lop: " + lop);
    }
}