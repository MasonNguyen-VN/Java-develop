package bai8;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QuanLyTheMuon ql = new QuanLyTheMuon();

        int chon;

        do {
            System.out.println("\n===== QUAN LY THE MUON =====");
            System.out.println("1. Them the muon");
            System.out.println("2. Xoa the muon theo ma");
            System.out.println("3. Hien thi danh sach the muon");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");

            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Nhap ma phieu muon: ");
                    String maPhieu = sc.nextLine();

                    System.out.print("Nhap ngay muon: ");
                    int ngayMuon = sc.nextInt();

                    System.out.print("Nhap han tra: ");
                    int hanTra = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nhap so hieu sach: ");
                    String soHieuSach = sc.nextLine();

                    System.out.print("Nhap ho ten sinh vien: ");
                    String hoTen = sc.nextLine();

                    System.out.print("Nhap tuoi: ");
                    int tuoi = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nhap lop: ");
                    String lop = sc.nextLine();

                    if (ngayMuon <= 0 || hanTra <= 0 || tuoi <= 0) {
                        System.out.println("Du lieu phai la so nguyen duong!");
                        break;
                    }

                    SinhVien sv = new SinhVien(hoTen, tuoi, lop);

                    TheMuon the = new TheMuon(
                            maPhieu, ngayMuon, hanTra,
                            soHieuSach, sv
                    );

                    ql.themTheMuon(the);
                    break;

                case 2:
                    System.out.print("Nhap ma phieu muon can xoa: ");
                    String maXoa = sc.nextLine();

                    ql.xoaTheMuon(maXoa);
                    break;

                case 3:
                    ql.hienThiDanhSach();
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}