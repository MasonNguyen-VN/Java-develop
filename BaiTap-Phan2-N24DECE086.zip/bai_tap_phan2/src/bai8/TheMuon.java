package bai8;

public class TheMuon {
    private String maPhieuMuon;
    private int ngayMuon;
    private int hanTra;
    private String soHieuSach;
    private SinhVien sinhVien;

    public TheMuon(String maPhieuMuon, int ngayMuon,
                   int hanTra, String soHieuSach,
                   SinhVien sinhVien) {
        this.maPhieuMuon = maPhieuMuon;
        this.ngayMuon = ngayMuon;
        this.hanTra = hanTra;
        this.soHieuSach = soHieuSach;
        this.sinhVien = sinhVien;
    }

    public String getMaPhieuMuon() {
        return maPhieuMuon;
    }

    public void hienThi() {
        System.out.println("Ma phieu muon: " + maPhieuMuon);
        System.out.println("Ngay muon: " + ngayMuon);
        System.out.println("Han tra: " + hanTra);
        System.out.println("So hieu sach: " + soHieuSach);

        System.out.println("--- Thong tin sinh vien ---");
        sinhVien.hienThi();

        System.out.println("----------------------------");
    }
}
