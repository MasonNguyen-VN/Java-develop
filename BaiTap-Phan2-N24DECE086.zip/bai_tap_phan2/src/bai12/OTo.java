package bai12;

public class OTo extends PhuongTien {
    private int soChoNgoi;
    private String kieuDongCo;

    public OTo(String maPT, String hangSanXuat, int namSanXuat,
               double giaBan, String mau, int soChoNgoi,
               String kieuDongCo) {

        super(maPT, hangSanXuat, namSanXuat, giaBan, mau);
        this.soChoNgoi = soChoNgoi;
        this.kieuDongCo = kieuDongCo;
    }

    @Override
    public void hienThi() {
        System.out.println("\n--- O TO ---");
        super.hienThi();
        System.out.println("So cho ngoi: " + soChoNgoi);
        System.out.println("Kieu dong co: " + kieuDongCo);
    }
}