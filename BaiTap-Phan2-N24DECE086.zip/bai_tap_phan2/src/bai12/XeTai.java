package bai12;

public class XeTai extends PhuongTien {
    private double trongTai;

    public XeTai(String maPT, String hangSanXuat, int namSanXuat,
                 double giaBan, String mau, double trongTai) {

        super(maPT, hangSanXuat, namSanXuat, giaBan, mau);
        this.trongTai = trongTai;
    }

    @Override
    public void hienThi() {
        System.out.println("\n--- XE TAI ---");
        super.hienThi();
        System.out.println("Trong tai: " + trongTai);
    }
}