package bai12;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QLPTGT ql = new QLPTGT();

        int chon;

        do {
            System.out.println("\n===== QUAN LY PHUONG TIEN =====");
            System.out.println("1. Them o to");
            System.out.println("2. Them xe may");
            System.out.println("3. Them xe tai");
            System.out.println("4. Xoa theo ma");
            System.out.println("5. Tim theo hang san xuat");
            System.out.println("6. Tim theo mau");
            System.out.println("7. Hien thi tat ca");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");

            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Ma phuong tien: ");
                    String maOTo = sc.nextLine();

                    System.out.print("Hang san xuat: ");
                    String hangOTo = sc.nextLine();

                    System.out.print("Nam san xuat: ");
                    int namOTo = sc.nextInt();

                    System.out.print("Gia ban: ");
                    double giaOTo = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Mau: ");
                    String mauOTo = sc.nextLine();

                    System.out.print("So cho ngoi: ");
                    int soCho = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Kieu dong co: ");
                    String dongCo = sc.nextLine();

                    ql.them(new OTo(maOTo, hangOTo, namOTo,
                            giaOTo, mauOTo, soCho, dongCo));
                    break;

                case 2:
                    System.out.print("Ma phuong tien: ");
                    String maXeMay = sc.nextLine();

                    System.out.print("Hang san xuat: ");
                    String hangXeMay = sc.nextLine();

                    System.out.print("Nam san xuat: ");
                    int namXeMay = sc.nextInt();

                    System.out.print("Gia ban: ");
                    double giaXeMay = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Mau: ");
                    String mauXeMay = sc.nextLine();

                    System.out.print("Cong suat: ");
                    double congSuat = sc.nextDouble();

                    ql.them(new XeMay(maXeMay, hangXeMay, namXeMay,
                            giaXeMay, mauXeMay, congSuat));
                    break;

                case 3:
                    System.out.print("Ma phuong tien: ");
                    String maXeTai = sc.nextLine();

                    System.out.print("Hang san xuat: ");
                    String hangXeTai = sc.nextLine();

                    System.out.print("Nam san xuat: ");
                    int namXeTai = sc.nextInt();

                    System.out.print("Gia ban: ");
                    double giaXeTai = sc.nextDouble();
                    sc.nextLine();

                    System.out.print("Mau: ");
                    String mauXeTai = sc.nextLine();

                    System.out.print("Trong tai: ");
                    double trongTai = sc.nextDouble();

                    ql.them(new XeTai(maXeTai, hangXeTai, namXeTai,
                            giaXeTai, mauXeTai, trongTai));
                    break;

                case 4:
                    System.out.print("Nhap ma can xoa: ");
                    String maXoa = sc.nextLine();
                    ql.xoa(maXoa);
                    break;

                case 5:
                    System.out.print("Nhap hang san xuat: ");
                    String hang = sc.nextLine();
                    ql.timTheoHang(hang);
                    break;

                case 6:
                    System.out.print("Nhap mau xe: ");
                    String mau = sc.nextLine();
                    ql.timTheoMau(mau);
                    break;

                case 7:
                    ql.hienThiTatCa();
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}