package bai12;

public class PhuongTien {
    protected String maPT;
    protected String hangSanXuat;
    protected int namSanXuat;
    protected double giaBan;
    protected String mau;

    public PhuongTien(String maPT, String hangSanXuat,
                      int namSanXuat, double giaBan, String mau) {
        this.maPT = maPT;
        this.hangSanXuat = hangSanXuat;
        this.namSanXuat = namSanXuat;
        this.giaBan = giaBan;
        this.mau = mau;
    }

    public String getMaPT() {
        return maPT;
    }

    public String getHangSanXuat() {
        return hangSanXuat;
    }

    public String getMau() {
        return mau;
    }

    public void hienThi() {
        System.out.println("Ma phuong tien: " + maPT);
        System.out.println("Hang san xuat: " + hangSanXuat);
        System.out.println("Nam san xuat: " + namSanXuat);
        System.out.println("Gia ban: " + giaBan);
        System.out.println("Mau: " + mau);
    }
}