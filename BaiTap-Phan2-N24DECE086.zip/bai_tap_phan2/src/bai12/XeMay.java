package bai12;

public class XeMay extends PhuongTien {
    private double congSuat;

    public XeMay(String maPT, String hangSanXuat, int namSanXuat,
                 double giaBan, String mau, double congSuat) {

        super(maPT, hangSanXuat, namSanXuat, giaBan, mau);
        this.congSuat = congSuat;
    }

    @Override
    public void hienThi() {
        System.out.println("\n--- XE MAY ---");
        super.hienThi();
        System.out.println("Cong suat: " + congSuat);
    }
}