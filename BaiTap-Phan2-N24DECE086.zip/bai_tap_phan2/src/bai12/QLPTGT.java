package bai12;

import java.util.ArrayList;

public class QLPTGT {
    private ArrayList<PhuongTien> danhSach = new ArrayList<>();

    // Thêm phương tiện
    public void them(PhuongTien pt) {
        for (PhuongTien x : danhSach) {
            if (x.getMaPT().equalsIgnoreCase(pt.getMaPT())) {
                System.out.println("Ma phuong tien da ton tai!");
                return;
            }
        }

        danhSach.add(pt);
        System.out.println("Them thanh cong!");
    }

    // Xóa theo mã phương tiện
    public void xoa(String ma) {
        for (int i = 0; i < danhSach.size(); i++) {
            if (danhSach.get(i).getMaPT().equalsIgnoreCase(ma)) {
                danhSach.remove(i);
                System.out.println("Xoa thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay phuong tien!");
    }

    // Tìm theo hãng sản xuất
    public void timTheoHang(String hang) {
        boolean timThay = false;

        for (PhuongTien pt : danhSach) {
            if (pt.getHangSanXuat().equalsIgnoreCase(hang)) {
                pt.hienThi();
                timThay = true;
            }
        }

        if (!timThay) {
            System.out.println("Khong tim thay!");
        }
    }

    // Tìm theo màu
    public void timTheoMau(String mau) {
        boolean timThay = false;

        for (PhuongTien pt : danhSach) {
            if (pt.getMau().equalsIgnoreCase(mau)) {
                pt.hienThi();
                timThay = true;
            }
        }

        if (!timThay) {
            System.out.println("Khong tim thay!");
        }
    }

    // Hiển thị toàn bộ danh sách
    public void hienThiTatCa() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach trong!");
            return;
        }

        for (PhuongTien pt : danhSach) {
            pt.hienThi();
        }
    }
}