package bai7;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QuanLyCBGV ql = new QuanLyCBGV();

        int chon;

        do {
            System.out.println("\n===== QUAN LY GIAO VIEN =====");
            System.out.println("1. Them giao vien");
            System.out.println("2. Xoa giao vien theo ma");
            System.out.println("3. Hien thi danh sach va luong");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");

            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Nhap ho ten: ");
                    String hoTen = sc.nextLine();

                    System.out.print("Nhap tuoi: ");
                    int tuoi = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nhap que quan: ");
                    String queQuan = sc.nextLine();

                    System.out.print("Nhap ma giao vien: ");
                    String maGV = sc.nextLine();

                    System.out.print("Nhap luong cung: ");
                    double luongCung = sc.nextDouble();

                    System.out.print("Nhap luong thuong: ");
                    double luongThuong = sc.nextDouble();

                    System.out.print("Nhap tien phat: ");
                    double tienPhat = sc.nextDouble();
                    sc.nextLine();

                    Nguoi nguoi = new Nguoi(hoTen, tuoi, queQuan);

                    CBGV gv = new CBGV(
                            nguoi, maGV,
                            luongCung, luongThuong, tienPhat
                    );

                    ql.themGiaoVien(gv);
                    break;

                case 2:
                    System.out.print("Nhap ma giao vien can xoa: ");
                    String maXoa = sc.nextLine();

                    ql.xoaGiaoVien(maXoa);
                    break;

                case 3:
                    ql.hienThiDanhSach();
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}