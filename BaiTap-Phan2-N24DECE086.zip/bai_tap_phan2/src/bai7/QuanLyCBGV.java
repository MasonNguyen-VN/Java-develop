package bai7;

import java.util.ArrayList;

public class QuanLyCBGV {
    private ArrayList<CBGV> danhSach = new ArrayList<>();

    // Them giao vien
    public void themGiaoVien(CBGV gv) {
        for (CBGV item : danhSach) {
            if (item.getMaGV().equalsIgnoreCase(gv.getMaGV())) {
                System.out.println("Ma giao vien da ton tai!");
                return;
            }
        }

        danhSach.add(gv);
        System.out.println("Them giao vien thanh cong!");
    }

    // Xoa giao vien theo ma
    public void xoaGiaoVien(String maGV) {
        for (CBGV gv : danhSach) {
            if (gv.getMaGV().equalsIgnoreCase(maGV)) {
                danhSach.remove(gv);
                System.out.println("Xoa giao vien thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay giao vien!");
    }

    // Hien thi danh sach
    public void hienThiDanhSach() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach giao vien trong!");
            return;
        }

        for (CBGV gv : danhSach) {
            gv.hienThi();
        }
    }
}