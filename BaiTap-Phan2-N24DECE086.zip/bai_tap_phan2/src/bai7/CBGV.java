package bai7;

public class CBGV {
    private Nguoi nguoi;
    private String maGV;
    private double luongCung;
    private double luongThuong;
    private double tienPhat;

    public CBGV(Nguoi nguoi, String maGV,
                double luongCung, double luongThuong,
                double tienPhat) {
        this.nguoi = nguoi;
        this.maGV = maGV;
        this.luongCung = luongCung;
        this.luongThuong = luongThuong;
        this.tienPhat = tienPhat;
    }

    public String getMaGV() {
        return maGV;
    }

    public double tinhLuongThucLinh() {
        return luongCung + luongThuong - tienPhat;
    }

    public void hienThi() {
        nguoi.hienThi();

        System.out.println("Ma giao vien: " + maGV);
        System.out.println("Luong cung: " + luongCung);
        System.out.println("Luong thuong: " + luongThuong);
        System.out.println("Tien phat: " + tienPhat);
        System.out.println("Luong thuc linh: " + tinhLuongThucLinh());
        System.out.println("----------------------------");
    }
}