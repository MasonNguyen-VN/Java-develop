package bai9;

public class KhachHang {
    private String hoTenChuHo;
    private String soNha;
    private String maCongTo;

    public KhachHang(String hoTenChuHo, String soNha, String maCongTo) {
        this.hoTenChuHo = hoTenChuHo;
        this.soNha = soNha;
        this.maCongTo = maCongTo;
    }

    public String getMaCongTo() {
        return maCongTo;
    }

    public void setHoTenChuHo(String hoTenChuHo) {
        this.hoTenChuHo = hoTenChuHo;
    }

    public void setSoNha(String soNha) {
        this.soNha = soNha;
    }

    public void hienThi() {
        System.out.println("Chu ho: " + hoTenChuHo);
        System.out.println("So nha: " + soNha);
        System.out.println("Ma cong to: " + maCongTo);
    }
}