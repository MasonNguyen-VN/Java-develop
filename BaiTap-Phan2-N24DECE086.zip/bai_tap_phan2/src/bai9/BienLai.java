package bai9;

public class BienLai {
    private KhachHang khachHang;
    private int chiSoCu;
    private int chiSoMoi;

    public BienLai(KhachHang khachHang, int chiSoCu, int chiSoMoi) {
        this.khachHang = khachHang;
        this.chiSoCu = chiSoCu;
        this.chiSoMoi = chiSoMoi;
    }

    public String getMaCongTo() {
        return khachHang.getMaCongTo();
    }

    public void capNhatKhachHang(String hoTenChuHo, String soNha) {
        khachHang.setHoTenChuHo(hoTenChuHo);
        khachHang.setSoNha(soNha);
    }

    public double tinhTienDien() {
        return (chiSoMoi - chiSoCu) * 5;
    }

    public void hienThi() {
        khachHang.hienThi();

        System.out.println("Chi so cu: " + chiSoCu);
        System.out.println("Chi so moi: " + chiSoMoi);
        System.out.println("Tien dien: " + tinhTienDien());
        System.out.println("----------------------------");
    }
}