package bai9;

import java.util.ArrayList;

public class QuanLyBienLai {
    private ArrayList<BienLai> danhSach = new ArrayList<>();

    // Them bien lai
    public void themBienLai(BienLai bl) {
        for (BienLai item : danhSach) {
            if (item.getMaCongTo().equalsIgnoreCase(bl.getMaCongTo())) {
                System.out.println("Ma cong to da ton tai!");
                return;
            }
        }

        danhSach.add(bl);
        System.out.println("Them bien lai thanh cong!");
    }

    // Xoa bien lai theo ma cong to
    public void xoaBienLai(String maCongTo) {
        for (int i = 0; i < danhSach.size(); i++) {
            if (danhSach.get(i).getMaCongTo().equalsIgnoreCase(maCongTo)) {
                danhSach.remove(i);
                System.out.println("Xoa bien lai thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay ma cong to!");
    }

    // Sua thong tin khach hang
    public void suaThongTinKhachHang(String maCongTo,
                                     String hoTenMoi, String soNhaMoi) {
        for (BienLai bl : danhSach) {
            if (bl.getMaCongTo().equalsIgnoreCase(maCongTo)) {
                bl.capNhatKhachHang(hoTenMoi, soNhaMoi);
                System.out.println("Cap nhat thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay ma cong to!");
    }

    // Hien thi danh sach
    public void hienThiDanhSach() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach bien lai trong!");
            return;
        }

        for (BienLai bl : danhSach) {
            bl.hienThi();
        }
    }
}