package bai9;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QuanLyBienLai ql = new QuanLyBienLai();

        int chon;

        do {
            System.out.println("\n===== QUAN LY BIEN LAI DIEN =====");
            System.out.println("1. Them bien lai");
            System.out.println("2. Xoa bien lai");
            System.out.println("3. Sua thong tin khach hang");
            System.out.println("4. Hien thi danh sach");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");

            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Nhap ho ten chu ho: ");
                    String hoTen = sc.nextLine();

                    System.out.print("Nhap so nha: ");
                    String soNha = sc.nextLine();

                    System.out.print("Nhap ma cong to: ");
                    String maCongTo = sc.nextLine();

                    System.out.print("Nhap chi so cu: ");
                    int chiSoCu = sc.nextInt();

                    System.out.print("Nhap chi so moi: ");
                    int chiSoMoi = sc.nextInt();
                    sc.nextLine();

                    if (chiSoCu < 0 || chiSoMoi < chiSoCu) {
                        System.out.println("Chi so dien khong hop le!");
                        break;
                    }

                    KhachHang kh = new KhachHang(hoTen, soNha, maCongTo);

                    BienLai bl = new BienLai(kh, chiSoCu, chiSoMoi);

                    ql.themBienLai(bl);
                    break;

                case 2:
                    System.out.print("Nhap ma cong to can xoa: ");
                    String maXoa = sc.nextLine();

                    ql.xoaBienLai(maXoa);
                    break;

                case 3:
                    System.out.print("Nhap ma cong to can sua: ");
                    String maSua = sc.nextLine();

                    System.out.print("Nhap ten chu ho moi: ");
                    String tenMoi = sc.nextLine();

                    System.out.print("Nhap so nha moi: ");
                    String nhaMoi = sc.nextLine();

                    ql.suaThongTinKhachHang(maSua, tenMoi, nhaMoi);
                    break;

                case 4:
                    ql.hienThiDanhSach();
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}