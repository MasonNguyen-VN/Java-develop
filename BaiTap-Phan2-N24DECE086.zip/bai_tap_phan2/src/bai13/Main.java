package bai13;

import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    // Ham nhap chuoi
    public static String nhapChuoi(String thongBao) {
        System.out.print(thongBao);
        return sc.nextLine();
    }

    // Ham nhap so nguyen
    public static int nhapSoNguyen(String thongBao) {
        while (true) {
            try {
                System.out.print(thongBao);
                return Integer.parseInt(sc.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Vui long nhap so nguyen!");
            }
        }
    }

    // Nhap thong tin chung
    public static String[] nhapThongTinChung() {
        String[] a = new String[5];

        a[0] = nhapChuoi("Nhap ID: ");
        a[1] = nhapChuoi("Nhap ho ten: ");
        a[2] = nhapChuoi("Nhap ngay sinh (dd/MM/yyyy): ");
        a[3] = nhapChuoi("Nhap so dien thoai: ");
        a[4] = nhapChuoi("Nhap email: ");

        return a;
    }

    // Them Intern
    public static void themIntern(EmployeeManager ql) {
        String[] a = nhapThongTinChung();

        String majors = nhapChuoi("Nhap chuyen nganh: ");
        int semester = nhapSoNguyen("Nhap hoc ky: ");
        String university = nhapChuoi("Nhap ten truong: ");

        Employee e = new Intern(
            a[0], a[1], a[2], a[3], a[4],
            majors, semester, university
        );

        try {
            ql.them(e);
        } catch (BirthDayException | PhoneException |
                 EmailException | FullNameException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    // Them Fresher
    public static void themFresher(EmployeeManager ql) {
        String[] a = nhapThongTinChung();

        String graduationDate =
            nhapChuoi("Nhap ngay tot nghiep: ");

        String graduationRank =
            nhapChuoi("Nhap xep loai tot nghiep: ");

        String education =
            nhapChuoi("Nhap truong hoc: ");

        Employee e = new Fresher(
            a[0], a[1], a[2], a[3], a[4],
            graduationDate, graduationRank, education
        );

        try {
            ql.them(e);
        } catch (BirthDayException | PhoneException |
                 EmailException | FullNameException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    // Them Experience
    public static void themExperience(EmployeeManager ql) {
        String[] a = nhapThongTinChung();

        int expInYear =
            nhapSoNguyen("Nhap so nam kinh nghiem: ");

        String proSkill =
            nhapChuoi("Nhap ky nang chuyen mon: ");

        Employee e = new Experience(
            a[0], a[1], a[2], a[3], a[4],
            expInYear, proSkill
        );

        try {
            ql.them(e);
        } catch (BirthDayException | PhoneException |
                 EmailException | FullNameException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    // Sua nhan vien
    public static void suaNhanVien(EmployeeManager ql) {
        String id = nhapChuoi("Nhap ID nhan vien can sua: ");

        String ten = nhapChuoi("Nhap ho ten moi: ");
        String ngaySinh =
            nhapChuoi("Nhap ngay sinh moi (dd/MM/yyyy): ");

        String phone = nhapChuoi("Nhap so dien thoai moi: ");
        String email = nhapChuoi("Nhap email moi: ");

        try {
            ql.sua(id, ten, ngaySinh, phone, email);
        } catch (BirthDayException | PhoneException |
                 EmailException | FullNameException ex) {
            System.out.println("Loi: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {

        EmployeeManager ql = new EmployeeManager();

        int chon;

        do {
            System.out.println("\n========== QUAN LY NHAN VIEN ==========");
            System.out.println("1. Them Intern");
            System.out.println("2. Them Fresher");
            System.out.println("3. Them Experience");
            System.out.println("4. Sua thong tin nhan vien");
            System.out.println("5. Xoa nhan vien");
            System.out.println("6. Hien thi tat ca nhan vien");
            System.out.println("7. Tim Intern");
            System.out.println("8. Tim Experience");
            System.out.println("9. Tim Fresher");
            System.out.println("0. Thoat");
            System.out.println("=======================================");

            chon = nhapSoNguyen("Nhap lua chon: ");

            switch (chon) {

                case 1:
                    themIntern(ql);
                    break;

                case 2:
                    themFresher(ql);
                    break;

                case 3:
                    themExperience(ql);
                    break;

                case 4:
                    suaNhanVien(ql);
                    break;

                case 5:
                    String id = nhapChuoi("Nhap ID can xoa: ");
                    ql.xoa(id);
                    break;

                case 6:
                    ql.hienThiTatCa();
                    break;

                case 7:
                    ql.timIntern();
                    break;

                case 8:
                    ql.timExperience();
                    break;

                case 9:
                    ql.timFresher();
                    break;

                case 0:
                    System.out.println("Da thoat chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}