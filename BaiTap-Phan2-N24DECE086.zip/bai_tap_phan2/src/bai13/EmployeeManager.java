package bai13;

import java.util.ArrayList;

public class EmployeeManager {
    private ArrayList<Employee> danhSach = new ArrayList<>();

    // Thêm nhân viên
    public void them(Employee e)
            throws BirthDayException, PhoneException,
                   EmailException, FullNameException {

        // Kiem tra ID trung
        for (Employee x : danhSach) {
            if (x.getID().equalsIgnoreCase(e.getID())) {
                System.out.println("ID da ton tai!");
                return;
            }
        }

        // Kiem tra thong tin
        EmployeeValidator.validateFullName(e.FullName);
        EmployeeValidator.validateBirthDay(e.BirthDay);
        EmployeeValidator.validatePhone(e.Phone);
        EmployeeValidator.validateEmail(e.Email);

        // Chi them khi tat ca du lieu hop le
        danhSach.add(e);
        Employee.Employee_count++;

        System.out.println("Them nhan vien thanh cong!");
    }

    // Xóa nhân viên theo ID
    public void xoa(String id) {
        for (int i = 0; i < danhSach.size(); i++) {
            if (danhSach.get(i).getID().equalsIgnoreCase(id)) {
                danhSach.remove(i);
                Employee.giamEmployeeCount();

                System.out.println("Xoa thanh cong!");
                return;
            }
        }

        System.out.println("Khong tim thay nhan vien!");
    }

    // Tìm nhân viên theo ID
    public Employee timTheoID(String id) {
        for (Employee e : danhSach) {
            if (e.getID().equalsIgnoreCase(id)) {
                return e;
            }
        }

        return null;
    }

    // Hiển thị tất cả nhân viên
    public void hienThiTatCa() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach nhan vien trong!");
            return;
        }

        for (Employee e : danhSach) {
            e.showInfo();
        }
    }

    public void timIntern() {
        for (Employee e : danhSach) {
            if (e instanceof Intern) {
                Intern intern = (Intern) e;
                intern.showInfo();
            }
        }
    }

    // Tìm tất cả nhân viên Experience
    public void timExperience() {
        for (Employee e : danhSach) {
            if (e instanceof Experience) {
                Experience exp = (Experience) e;
                exp.showInfo();
            }
        }
    }
    // Tìm tất cả nhân viên Fresher
    public void timFresher() {
        for (Employee e : danhSach) {
            if (e instanceof Fresher) {
                Fresher fresher = (Fresher) e;
                fresher.showInfo();
            }
        }
    }
    public void sua(String id, String ten, String ngaySinh,
	            String phone, String email)
	    throws BirthDayException, PhoneException,
				           EmailException, FullNameException {
				
				Employee e = timTheoID(id);
				
				if (e == null) {
				    System.out.println("Khong tim thay nhan vien!");
				    return;
				}
				
				// Kiem tra du lieu moi truoc khi cap nhat
				EmployeeValidator.validateFullName(ten);
				EmployeeValidator.validateBirthDay(ngaySinh);
				EmployeeValidator.validatePhone(phone);
				EmployeeValidator.validateEmail(email);
				
				e.setFullName(ten);
				e.setBirthDay(ngaySinh);
				e.setPhone(phone);
				e.setEmail(email);
				
				System.out.println("Cap nhat thong tin thanh cong!");
				}
	    

    // Đếm nhân viên
    public int demNhanVien() {
        return danhSach.size();
    }
}