package bai13;

public class Fresher extends Employee {
    private String Graduation_date;
    private String Graduation_rank;
    private String Education;

    public Fresher(String ID, String FullName, String BirthDay,
                   String Phone, String Email,
                   String Graduation_date, String Graduation_rank,
                   String Education) {

        super(ID, FullName, BirthDay, Phone, Email, 1);

        this.Graduation_date = Graduation_date;
        this.Graduation_rank = Graduation_rank;
        this.Education = Education;
    }

    @Override
    public void showInfo() {
        System.out.println("\nLoai: Fresher");
        System.out.println("ID: " + ID);
        System.out.println("Ho ten: " + FullName);
        System.out.println("Ngay sinh: " + BirthDay);
        System.out.println("Phone: " + Phone);
        System.out.println("Email: " + Email);
        System.out.println("Thoi gian tot nghiep: " + Graduation_date);
        System.out.println("Xep loai: " + Graduation_rank);
        System.out.println("Truong tot nghiep: " + Education);

        for (Certificate c : certificates) {
            c.showInfo();
        }
    }
}