package bai13;

public class PhoneException extends Exception {
	private static final long serialVersionUID = 1L;
	public PhoneException(String message) {
        super(message);
    }
}