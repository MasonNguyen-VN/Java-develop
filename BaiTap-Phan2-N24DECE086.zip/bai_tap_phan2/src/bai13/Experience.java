package bai13;

public class Experience extends Employee {
    private int ExpInYear;
    private String ProSkill;

    public Experience(String ID, String FullName, String BirthDay,
                       String Phone, String Email,
                       int ExpInYear, String ProSkill) {

        super(ID, FullName, BirthDay, Phone, Email, 0);

        this.ExpInYear = ExpInYear;
        this.ProSkill = ProSkill;
    }

    @Override
    public void showInfo() {
        System.out.println("\nLoai: Experience");
        System.out.println("ID: " + ID);
        System.out.println("Ho ten: " + FullName);
        System.out.println("Ngay sinh: " + BirthDay);
        System.out.println("Phone: " + Phone);
        System.out.println("Email: " + Email);
        System.out.println("So nam kinh nghiem: " + ExpInYear);
        System.out.println("Ky nang: " + ProSkill);

        for (Certificate c : certificates) {
            c.showInfo();
        }
    }
}