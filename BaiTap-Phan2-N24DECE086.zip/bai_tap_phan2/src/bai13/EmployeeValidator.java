package bai13 ;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;

public class EmployeeValidator {

    // Kiem tra ho ten
    public static void validateFullName(String name)
            throws FullNameException {

        if (name == null || !name.trim().matches("[\\p{L}]+([ ]+[\\p{L}]+)*")) {
            throw new FullNameException(
                "Ho ten khong hop le! Chi duoc chua chu cai va khoang trang."
            );
        }
    }

    // Kiem tra ngay sinh
    public static void validateBirthDay(String birthday)
            throws BirthDayException {

        if (birthday == null) {
            throw new BirthDayException("Ngay sinh khong duoc de trong!");
        }

        try {
            DateTimeFormatter formatter =
                DateTimeFormatter.ofPattern("dd/MM/uuuu")
                    .withResolverStyle(ResolverStyle.STRICT);

            LocalDate date = LocalDate.parse(birthday, formatter);

            if (date.isAfter(LocalDate.now())) {
                throw new BirthDayException(
                    "Ngay sinh khong duoc nam trong tuong lai!"
                );
            }

        } catch (DateTimeParseException e) {
            throw new BirthDayException(
                "Ngay sinh khong hop le! Hay nhap theo dd/MM/yyyy."
            );
        }
    }

    // Kiem tra so dien thoai
    public static void validatePhone(String phone)
            throws PhoneException {

        if (phone == null || !phone.matches("\\d{10}")) {
            throw new PhoneException(
                "So dien thoai phai gom dung 10 chu so!"
            );
        }
    }

    // Kiem tra email
    public static void validateEmail(String email)
            throws EmailException {

        String regex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";

        if (email == null || !email.matches(regex)) {
            throw new EmailException("Email khong dung dinh dang!");
        }
    }
}