package bai13;

import java.util.ArrayList;

public abstract class Employee {
    protected String ID;
    protected String FullName;
    protected String BirthDay;
    protected String Phone;
    protected String Email;
    protected int Employee_type;

    protected ArrayList<Certificate> certificates = new ArrayList<>();

    public static int Employee_count = 0;

    public Employee(String ID, String FullName, String BirthDay,
                    String Phone, String Email, int Employee_type) {
        this.ID = ID;
        this.FullName = FullName;
        this.BirthDay = BirthDay;
        this.Phone = Phone;
        this.Email = Email;
        this.Employee_type = Employee_type;

    }

    public String getID() {
        return ID;
    }

    public void setFullName(String FullName) {
        this.FullName = FullName;
    }

    public void setBirthDay(String BirthDay) {
        this.BirthDay = BirthDay;
    }

    public void setPhone(String Phone) {
        this.Phone = Phone;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public void themCertificate(Certificate c) {
        certificates.add(c);
    }

    // Phương thức trừu tượng
    public abstract void showInfo();

    // Giảm số lượng nhân viên khi xóa
    public static void giamEmployeeCount() {
        Employee_count--;
    }
}