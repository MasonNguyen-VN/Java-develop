package bai13;

public class Intern extends Employee {
    private String Majors;
    private int Semester;
    private String University_name;

    public Intern(String ID, String FullName, String BirthDay,
                  String Phone, String Email,
                  String Majors, int Semester, String University_name) {

        super(ID, FullName, BirthDay, Phone, Email, 2);

        this.Majors = Majors;
        this.Semester = Semester;
        this.University_name = University_name;
    }

    @Override
    public void showInfo() {
        System.out.println("\nLoai: Intern");
        System.out.println("ID: " + ID);
        System.out.println("Ho ten: " + FullName);
        System.out.println("Ngay sinh: " + BirthDay);
        System.out.println("Phone: " + Phone);
        System.out.println("Email: " + Email);
        System.out.println("Chuyen nganh: " + Majors);
        System.out.println("Hoc ky: " + Semester);
        System.out.println("Truong dang hoc: " + University_name);

        for (Certificate c : certificates) {
            c.showInfo();
        }
    }
}