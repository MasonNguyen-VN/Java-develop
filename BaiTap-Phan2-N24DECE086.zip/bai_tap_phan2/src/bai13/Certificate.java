package bai13;

public class Certificate {
    private String certificatedID;
    private String certificateName;
    private String certificateRank;
    private String certificatedDate;

    public Certificate(String certificatedID, String certificateName,
                       String certificateRank, String certificatedDate) {
        this.certificatedID = certificatedID;
        this.certificateName = certificateName;
        this.certificateRank = certificateRank;
        this.certificatedDate = certificatedDate;
    }

    public void showInfo() {
        System.out.println("Ma bang cap: " + certificatedID);
        System.out.println("Ten bang cap: " + certificateName);
        System.out.println("Xep loai: " + certificateRank);
        System.out.println("Ngay cap: " + certificatedDate);
    }
}