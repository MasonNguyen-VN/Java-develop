package bai11;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        SoPhuc sp1 = new SoPhuc();
        SoPhuc sp2 = new SoPhuc();

        System.out.println("Nhap so phuc thu nhat:");
        sp1.nhap(sc);

        System.out.println("\nNhap so phuc thu hai:");
        sp2.nhap(sc);

        System.out.print("\nSo phuc thu nhat: ");
        sp1.hienThi();

        System.out.print("So phuc thu hai: ");
        sp2.hienThi();

        SoPhuc tong = sp1.cong(sp2);
        SoPhuc tich = sp1.nhan(sp2);

        System.out.print("\nTong hai so phuc: ");
        tong.hienThi();

        System.out.print("Tich hai so phuc: ");
        tich.hienThi();

        sc.close();
    }
}