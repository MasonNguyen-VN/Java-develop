package bai11;

import java.util.Scanner;

public class SoPhuc {
    private double PhanThuc;
    private double PhanAo;

    // Constructor không tham số
    public SoPhuc() {
        PhanThuc = 0;
        PhanAo = 0;
    }

    // Constructor có tham số
    public SoPhuc(double PhanThuc, double PhanAo) {
        this.PhanThuc = PhanThuc;
        this.PhanAo = PhanAo;
    }

    // Nhập số phức
    public void nhap(Scanner sc) {
        System.out.print("Nhap phan thuc: ");
        PhanThuc = sc.nextDouble();

        System.out.print("Nhap phan ao: ");
        PhanAo = sc.nextDouble();
    }

    // Hiển thị số phức
    public void hienThi() {
        if (PhanAo < 0) {
            System.out.println(PhanThuc + " - " + Math.abs(PhanAo) + "i");
        } else {
            System.out.println(PhanThuc + " + " + PhanAo + "i");
        }
    }

    // Cộng hai số phức
    public SoPhuc cong(SoPhuc sp) {
        double thuc = this.PhanThuc + sp.PhanThuc;
        double ao = this.PhanAo + sp.PhanAo;

        return new SoPhuc(thuc, ao);
    }

    // Nhân hai số phức
    public SoPhuc nhan(SoPhuc sp) {
        double thuc = this.PhanThuc * sp.PhanThuc
                    - this.PhanAo * sp.PhanAo;

        double ao = this.PhanThuc * sp.PhanAo
                  + this.PhanAo * sp.PhanThuc;

        return new SoPhuc(thuc, ao);
    }
}