package n24dece086;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        QuanLyHocSinh ql = new QuanLyHocSinh();

        int chon;

        do {
            System.out.println("\n===== QUAN LY HOC SINH =====");
            System.out.println("1. Them hoc sinh");
            System.out.println("2. Hien thi hoc sinh 20 tuoi");
            System.out.println("3. Dem hoc sinh 23 tuoi que DN");
            System.out.println("0. Thoat");
            System.out.print("Nhap lua chon: ");

            chon = sc.nextInt();
            sc.nextLine();

            switch (chon) {
                case 1:
                    System.out.print("Nhap ho ten: ");
                    String hoTen = sc.nextLine();

                    System.out.print("Nhap tuoi: ");
                    int tuoi = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nhap que quan: ");
                    String queQuan = sc.nextLine();

                    System.out.print("Nhap lop: ");
                    String lop = sc.nextLine();

                    HocSinh hs = new HocSinh(
                            hoTen, tuoi, queQuan, lop
                    );

                    ql.themHocSinh(hs);
                    break;

                case 2:
                    ql.hienThiHocSinh20Tuoi();
                    break;

                case 3:
                    System.out.println(
                            "So hoc sinh 23 tuoi, que DN: "
                            + ql.demHocSinh23TuoiDN()
                    );
                    break;

                case 0:
                    System.out.println("Ket thuc chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (chon != 0);

        sc.close();
    }
}