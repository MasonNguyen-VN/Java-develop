package n24dece086;

public class HocSinh {
    private String hoTen;
    private int tuoi;
    private String queQuan;
    private String lop;

    public HocSinh(String hoTen, int tuoi, String queQuan, String lop) {
        this.hoTen = hoTen;
        this.tuoi = tuoi;
        this.queQuan = queQuan;
        this.lop = lop;
    }

    public int getTuoi() {
        return tuoi;
    }

    public String getQueQuan() {
        return queQuan;
    }

    public void hienThi() {
        System.out.println("Ho ten: " + hoTen);
        System.out.println("Tuoi: " + tuoi);
        System.out.println("Que quan: " + queQuan);
        System.out.println("Lop: " + lop);
        System.out.println("--------------------");
    }
}