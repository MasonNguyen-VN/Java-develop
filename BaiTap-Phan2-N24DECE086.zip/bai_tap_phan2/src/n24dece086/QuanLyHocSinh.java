package n24dece086;

import java.util.ArrayList;

public class QuanLyHocSinh {
    private ArrayList<HocSinh> danhSach = new ArrayList<>();

    // Them hoc sinh
    public void themHocSinh(HocSinh hs) {
        danhSach.add(hs);
        System.out.println("Them hoc sinh thanh cong!");
    }

    // Hien thi hoc sinh co tuoi bang 20
    public void hienThiHocSinh20Tuoi() {
        boolean timThay = false;

        for (HocSinh hs : danhSach) {
            if (hs.getTuoi() == 20) {
                hs.hienThi();
                timThay = true;
            }
        }

        if (!timThay) {
            System.out.println("Khong co hoc sinh nao 20 tuoi.");
        }
    }

    // Dem hoc sinh 23 tuoi va que quan DN
    public int demHocSinh23TuoiDN() {
        int dem = 0;

        for (HocSinh hs : danhSach) {
            if (hs.getTuoi() == 23
                    && hs.getQueQuan().equalsIgnoreCase("DN")) {
                dem++;
            }
        }

        return dem;
    }
}