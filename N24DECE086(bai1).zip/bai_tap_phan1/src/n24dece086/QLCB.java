package n24dece086;

import java.util.ArrayList;

public class QLCB {
    private ArrayList<CanBo> danhSach;

    public QLCB() {
        danhSach = new ArrayList<>();
    }

    // Them can bo
    public void themCanBo(CanBo cb) {
        danhSach.add(cb);
        System.out.println("Them can bo thanh cong!");
    }

    // Tim kiem theo ho ten
    public void timKiemTheoHoTen(String tuKhoa) {
        boolean timThay = false;

        for (CanBo cb : danhSach) {
            if (cb.getHoTen().toLowerCase()
                    .contains(tuKhoa.toLowerCase())) {

                System.out.println("\n" + cb);
                System.out.println("-------------------------");
                timThay = true;
            }
        }

        if (!timThay) {
            System.out.println("Khong tim thay can bo!");
        }
    }

    // Hien thi danh sach
    public void hienThiDanhSach() {
        if (danhSach.isEmpty()) {
            System.out.println("Danh sach can bo rong!");
            return;
        }

        System.out.println("\n===== DANH SACH CAN BO =====");

        for (int i = 0; i < danhSach.size(); i++) {
            System.out.println("\nCan bo thu " + (i + 1));
            System.out.println(danhSach.get(i));
            System.out.println("-------------------------");
        }
    }
}