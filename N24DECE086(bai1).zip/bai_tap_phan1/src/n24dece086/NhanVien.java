package n24dece086;

public class NhanVien extends CanBo {
    private String congViec;

    public NhanVien(String hoTen, int tuoi, String gioiTinh,
                    String diaChi, String congViec) {
        super(hoTen, tuoi, gioiTinh, diaChi);
        this.congViec = congViec;
    }

    public String getCongViec() {
        return congViec;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nLoai can bo: Nhan vien"
                + "\nCong viec: " + congViec;
    }
}