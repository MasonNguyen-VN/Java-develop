package n24dece086;

public class CongNhan extends CanBo {
    private int bac;

    public CongNhan(String hoTen, int tuoi, String gioiTinh,
                    String diaChi, int bac) {
        super(hoTen, tuoi, gioiTinh, diaChi);

        if (bac < 1 || bac > 10) {
            throw new IllegalArgumentException(
                    "Bac cong nhan phai tu 1 den 10!"
            );
        }

        this.bac = bac;
    }

    public int getBac() {
        return bac;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nLoai can bo: Cong nhan"
                + "\nBac: " + bac;
    }
}