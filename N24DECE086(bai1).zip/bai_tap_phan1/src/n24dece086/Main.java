package n24dece086;

import java.util.Scanner;

public class Main {

    private static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        QLCB qlcb = new QLCB();

        int luaChon;

        do {
            hienThiMenu();
            luaChon = nhapSoNguyen("Nhap lua chon: ");

            switch (luaChon) {
                case 1:
                    themCanBo(qlcb);
                    break;

                case 2:
                    System.out.print("Nhap ho ten can tim: ");
                    String tuKhoa = sc.nextLine();

                    qlcb.timKiemTheoHoTen(tuKhoa);
                    break;

                case 3:
                    qlcb.hienThiDanhSach();
                    break;

                case 4:
                    System.out.println("Da thoat chuong trinh!");
                    break;

                default:
                    System.out.println("Lua chon khong hop le!");
            }

        } while (luaChon != 4);

        sc.close();
    }

    // Hien thi menu
    public static void hienThiMenu() {
        System.out.println("\n========== QUAN LY CAN BO ==========");
        System.out.println("1. Them moi can bo");
        System.out.println("2. Tim kiem theo ho ten");
        System.out.println("3. Hien thi danh sach can bo");
        System.out.println("4. Thoat chuong trinh");
        System.out.println("====================================");
    }

    // Nhap so nguyen co kiem tra
    public static int nhapSoNguyen(String thongBao) {
        while (true) {
            System.out.print(thongBao);

            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Vui long nhap so nguyen!");
            }
        }
    }

    // Nhap thong tin va them can bo
    public static void themCanBo(QLCB qlcb) {
        System.out.println("\n===== THEM CAN BO =====");
        System.out.println("1. Cong nhan");
        System.out.println("2. Ky su");
        System.out.println("3. Nhan vien");

        int loai = nhapSoNguyen("Chon loai can bo: ");

        if (loai < 1 || loai > 3) {
            System.out.println("Loai can bo khong hop le!");
            return;
        }

        System.out.print("Nhap ho ten: ");
        String hoTen = sc.nextLine().trim();

        if (hoTen.isEmpty()) {
            System.out.println("Ho ten khong duoc de trong!");
            return;
        }

        int tuoi = nhapSoNguyen("Nhap tuoi: ");

        if (tuoi <= 0) {
            System.out.println("Tuoi phai lon hon 0!");
            return;
        }

        System.out.println("Chon gioi tinh:");
        System.out.println("1. Nam");
        System.out.println("2. Nu");
        System.out.println("3. Khac");

        int chonGioiTinh = nhapSoNguyen("Nhap lua chon: ");

        String gioiTinh;

        switch (chonGioiTinh) {
            case 1:
                gioiTinh = "Nam";
                break;
            case 2:
                gioiTinh = "Nu";
                break;
            case 3:
                gioiTinh = "Khac";
                break;
            default:
                System.out.println("Gioi tinh khong hop le!");
                return;
        }

        System.out.print("Nhap dia chi: ");
        String diaChi = sc.nextLine().trim();

        if (diaChi.isEmpty()) {
            System.out.println("Dia chi khong duoc de trong!");
            return;
        }

        try {
            switch (loai) {
                case 1:
                    int bac = nhapSoNguyen("Nhap bac cong nhan (1-10): ");

                    CongNhan cn = new CongNhan(
                            hoTen, tuoi, gioiTinh, diaChi, bac
                    );

                    qlcb.themCanBo(cn);
                    break;

                case 2:
                    System.out.print("Nhap nganh dao tao: ");
                    String nganh = sc.nextLine().trim();

                    if (nganh.isEmpty()) {
                        System.out.println("Nganh dao tao khong duoc de trong!");
                        return;
                    }

                    KySu ks = new KySu(
                            hoTen, tuoi, gioiTinh, diaChi, nganh
                    );

                    qlcb.themCanBo(ks);
                    break;

                case 3:
                    System.out.print("Nhap cong viec: ");
                    String congViec = sc.nextLine().trim();

                    if (congViec.isEmpty()) {
                        System.out.println("Cong viec khong duoc de trong!");
                        return;
                    }

                    NhanVien nv = new NhanVien(
                            hoTen, tuoi, gioiTinh, diaChi, congViec
                    );

                    qlcb.themCanBo(nv);
                    break;
            }

        } catch (IllegalArgumentException e) {
            System.out.println("Loi: " + e.getMessage());
        }
    }
}