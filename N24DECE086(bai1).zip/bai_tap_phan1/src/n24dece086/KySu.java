package n24dece086;

public class KySu extends CanBo {
    private String nganhDaoTao;

    public KySu(String hoTen, int tuoi, String gioiTinh,
                String diaChi, String nganhDaoTao) {
        super(hoTen, tuoi, gioiTinh, diaChi);
        this.nganhDaoTao = nganhDaoTao;
    }

    public String getNganhDaoTao() {
        return nganhDaoTao;
    }

    @Override
    public String toString() {
        return super.toString()
                + "\nLoai can bo: Ky su"
                + "\nNganh dao tao: " + nganhDaoTao;
    }
}